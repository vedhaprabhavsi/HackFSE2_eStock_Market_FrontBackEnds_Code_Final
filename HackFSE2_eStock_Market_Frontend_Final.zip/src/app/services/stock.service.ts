import { DatePipe } from "@angular/common";
import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { Stock } from "../models/stock";

@Injectable({
    providedIn: 'root',
})

export class StockService {
  baseUrl: string = "http://localhost:8481/query/market/stock/"

  stock = new Stock();

  constructor(private http: HttpClient,
    public datepipe: DatePipe) { }

  getCompanyStocks(companyCode: String, startDate:Date, endDate:Date): Observable<any> {
    console.log("Calling Java getCompanyStocks method");
    console.log(this.baseUrl+"get/"+companyCode+"/"+startDate+"/"+endDate);
    //let startDateStr =this.datepipe.transform(startDate, 'dd-MM-yyyy');
    //let endDateStr = this.datepipe.transform(endDate, 'dd-MM-yyyy')
    console.log("After Date Conversion:: "+this.baseUrl+"get/"+companyCode+"/"+startDate+"/"+endDate);
    return this.http.get<any>(this.baseUrl+"get/"+companyCode+"/"+startDate+"/"+endDate);
  }

  getAggregatePrice(companyCode: String){
    console.log("Calling Java getAggregatePrice method");
    return this.http.get<any>(this.baseUrl+"aggregate/"+companyCode);
  }
}