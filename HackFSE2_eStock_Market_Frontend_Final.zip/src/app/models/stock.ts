export class Stock {
    companyCode: string;
    companyName: string;
    price: number;
    startDate: Date;
    endDate: Date;
    createdOn: Date;
    updatedOn: Date;
  }