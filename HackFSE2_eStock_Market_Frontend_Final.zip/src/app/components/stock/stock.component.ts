import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Company } from 'src/app/models/company';
import { Stock } from 'src/app/models/stock';
import { StockAggregate } from 'src/app/models/stockAggregate';
import { CompanyService } from 'src/app/services/company.service';
import { StockService } from 'src/app/services/stock.service';
import { AuthService } from 'src/app/shared/auth.service';

@Component({
  selector: 'app-stock',
  templateUrl: './stock.component.html',
  styleUrls: ['./stock.component.css']
})
export class StockComponent implements OnInit {
  @ViewChild('v') viewStocksForm: NgForm;
  stock: Stock = new Stock();
  stockAggregate: StockAggregate = new StockAggregate();
  stocks = [{ "price": "", "createdOn": "" }];
  company: Company = new Company();
  errorMessage = '';
  submitted = false;
  loading = false;
  returnUrl: string;
  todate: Date;

  constructor(
    private auth: AuthService,
    private service: StockService,
    private companyService: CompanyService
  ) { }

  ngOnInit(): void {
    this.todate = new Date();
  }
  get f() { return this.viewStocksForm.controls; }

  onSubmit() {
    this.submitted = true;

    console.log(this.stock);
    this.service.getCompanyStocks(this.stock.companyCode, this.stock.startDate, this.stock.endDate).subscribe(data => {
      console.log("Stock Details :: " + data);
      if(data != ""){
        this.errorMessage = "";
        this.stocks = data;
      }else{
        this.errorMessage = "OOPS.. Stock details for company " + this.stock.companyCode + " are yet to add!!";
      }
    }, error => {
      console.log(error);
    });

    this.service.getAggregatePrice(this.stock.companyCode).subscribe(data => {
      console.log(data);
      this.stockAggregate = data[0];
      console.log(this.stockAggregate.companyCode);
    }, error => {
      console.log(error);
    });
  }

  fetchCompanyName(){
    this.companyService.getCompany(this.stock.companyCode).subscribe((data: any) => {
      //console.log(JSON.stringify(data.dependent[0]));
      console.log("Company Code: "+this.company.companyCode);
      this.stock.companyName = data.companyName;
      this.errorMessage="";
    }, error => {
        //this.errorMessage="Company ID "+this.company.companyCode+" doesn't exist!";
        this.viewStocksForm.reset();
        console.log(error);
    });
  }

  onReset(){
    this.viewStocksForm.reset();
    this.stocks = [{ "price": "", "createdOn": "" }];
    this.stockAggregate = new StockAggregate();;
  }

  logout() {
    this.auth.logout();
  }
}