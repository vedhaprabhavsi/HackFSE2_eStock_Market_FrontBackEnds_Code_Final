import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Company } from 'src/app/models/company';
import { CompanyService } from 'src/app/services/company.service';
import { AuthService } from 'src/app/shared/auth.service';

@Component({
  selector: 'app-company',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.css']
})
export class CompanyComponent implements OnInit {
  @ViewChild('r') registerForm: NgForm;
  company: Company = new Company();
  
  compCode = 0;
  submitted= false;
  loading = false;
  returnUrl: string;
  message='';
  errorMessage='';
  exList = [{"stockExchangeName":"BSE"},{"stockExchangeName":"NSE"}];
  
  constructor(
    private auth: AuthService,
    private service: CompanyService
  ) { }

  get f() { return this.registerForm.controls; }

  onSubmit(){
    console.log("Page is responding!");
    this.submitted = true;

    console.log(this.company);
    this.service.createCompany(this.company).subscribe(data => {
      console.log(data);
      this.compCode = data.companyCode;
      this.message="Company with code "+this.compCode+" is registered!!";
      this.company = new Company();
      this.registerForm.reset();
    }, error => {
      console.log(error);
  });
  }

  getCompanyDetails(){
    console.log("getCompanyDetails()");
    this.message="";
    this.service.getCompany(this.company.companyCode).subscribe((data: any) => {
      console.log("Company Code: "+this.company.companyCode);
      this.company.companyCode = data.companyCode;
      this.company.companyName = data.companyName;
      this.company.ceo = data.ceo;
      this.company.companyTurnover = data.companyTurnover;
      this.company.companyWebsite = data.companyWebsite;
      this.company.stockExchangeName = data.stockExchangeName;
      this.errorMessage="";
    }, error => {
      if(this.company.companyCode == undefined){
        this.errorMessage="Company ID is required for search!";
      }
      else{
        this.errorMessage="Company ID "+this.company.companyCode+" doesn't exist!";
      }
      this.registerForm.reset();
      console.log(error);
    });
  } 
  logout() {
    //this.router.navigate(['/login']);
    this.auth.logout();
  }
  ngOnInit(): void {
  }

}
