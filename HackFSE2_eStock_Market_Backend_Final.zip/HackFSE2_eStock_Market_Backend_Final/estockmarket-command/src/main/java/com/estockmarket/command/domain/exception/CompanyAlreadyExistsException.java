package com.estockmarket.command.domain.exception;

public class CompanyAlreadyExistsException extends RuntimeException {

}
