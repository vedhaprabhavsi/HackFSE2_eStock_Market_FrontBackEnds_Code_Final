package com.estockmarket.query.controller;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;

import com.estockmarket.query.application.controller.CompanyController;
import com.estockmarket.query.application.dto.CompanyDto;
import com.estockmarket.query.domain.service.CompanyService;

@SpringBootTest
class CompanyControllerTest {

	@InjectMocks
	private CompanyController companyController;

	@Mock
	private CompanyService companyService;
	
	@Test
	public void testGetCompany() {
		List<CompanyDto> companyList = new ArrayList<>();
		CompanyDto company = new CompanyDto();
		company.setCompanyCode("1002");
		company.setCompanyName("CTS");
		companyList.add(company);
		Mockito.when(companyService.getCompany()).thenReturn(companyList);
		ResponseEntity<List<CompanyDto>> result = companyController.getCompany();
		Assertions.assertEquals(1, result.getBody().size());		
	}
	
	@Test
	public void testGetCompanyId() {
		CompanyDto company = new CompanyDto();
		company.setCompanyCode("1002");
		company.setCompanyName("CTS");
		Mockito.when(companyService.getCompanyById("1002")).thenReturn(company);
		ResponseEntity<CompanyDto> result = companyController.getCompanyId("1002");
		Assertions.assertEquals("CTS", result.getBody().getCompanyName());		
	}

}
